import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { CHARACTERS } from "@/lib/worldData";
import { Sparkles, Zap, Users } from "lucide-react";
import CharacterCustomize from "@/components/game/CharacterCustomize";

export default function Landing() {
  const navigate = useNavigate();
  const [step, setStep] = useState("welcome"); // welcome, choose, username, customize
  const [selectedChar, setSelectedChar] = useState(null);
  const [username, setUsername] = useState("");
  const [customization, setCustomization] = useState({ color: "#a855f7", outfit: "default", outfitEmoji: null });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleStart() {
    if (!username.trim() || username.trim().length < 2) {
      setError("Username must be at least 2 characters!");
      return;
    }
    setLoading(true);
    setError("");
    try {
      // Check for existing save with this username + character
      const existing = await base44.entities.GameSave.filter({ username: username.trim(), character: selectedChar.id });
      let save;
      if (existing.length > 0) {
        save = existing[0];
        await base44.entities.GameSave.update(save.id, {
          online: true,
          last_played: new Date().toISOString(),
          character_color: customization.color,
        });
      } else {
        save = await base44.entities.GameSave.create({
          username: username.trim(),
          character: selectedChar.id,
          character_color: customization.color,
          pos_x: 400,
          pos_y: 300,
          current_world: "overworld",
          coins: 0,
          level: 1,
          xp: 0,
          inventory: [],
          completed_minigames: [],
          explored_areas: ["overworld"],
          high_scores: {},
          last_played: new Date().toISOString(),
          online: true,
        });
      }
      navigate(`/world?saveId=${save.id}`);
    } catch (e) {
      setError("Something went wrong. Try again!");
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden"
      style={{ background: "#000510" }}>

      {/* Retro scanline bg */}
      <div className="fixed inset-0 pointer-events-none" style={{
        backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.15) 3px, rgba(0,0,0,0.15) 4px)",
        zIndex: 1,
      }} />
      {/* Pixel grid */}
      <div className="fixed inset-0 pointer-events-none opacity-5" style={{
        backgroundImage: "linear-gradient(rgba(168,85,247,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(168,85,247,0.5) 1px, transparent 1px)",
        backgroundSize: "8px 8px",
        zIndex: 1,
      }} />
      {/* Floating neon orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 0 }}>
        {[...Array(12)].map((_, i) => (
          <div key={i} className="absolute rounded-full"
            style={{
              width: (i % 3 + 1) * 4,
              height: (i % 3 + 1) * 4,
              left: `${(i * 83) % 100}%`,
              top: `${(i * 67) % 100}%`,
              background: ['#a855f7','#22d3ee','#fbbf24','#ec4899'][i % 4],
              opacity: 0.25,
              animation: `floatAnim ${3 + (i % 4)}s ease-in-out infinite`,
              animationDelay: `${(i * 0.4) % 3}s`,
              boxShadow: `0 0 8px currentColor`,
            }} />
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* WELCOME SCREEN */}
        {step === "welcome" && (
          <motion.div key="welcome" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -30 }}
            className="text-center max-w-lg w-full">
            {/* Retro boot screen title */}
            <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 150, delay: 0.2 }}
              className="text-8xl mb-3 roxy-bounce inline-block"
              style={{ filter: "drop-shadow(0 0 20px rgba(168,85,247,0.8))" }}>🐕</motion.div>

            <div className="mb-1 font-orbitron text-xs tracking-[0.4em] text-purple-400 uppercase">
              ▶ INSERT COIN · PRESS START ◀
            </div>

            <h1 className="font-orbitron font-black text-4xl md:text-6xl mb-1 leading-tight" style={{
              background: "linear-gradient(135deg, #a855f7 0%, #22d3ee 50%, #fbbf24 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              textShadow: "none",
              filter: "drop-shadow(0 0 30px rgba(168,85,247,0.7))",
            }}>
              THE ADVENTURES<br />OF BUGGAGOOGEE
            </h1>

            {/* Retro pixel border decoration */}
            <div className="flex items-center gap-2 my-3 w-full justify-center">
              <div className="h-px flex-1 max-w-[80px]" style={{ background: "linear-gradient(90deg, transparent, #a855f7)" }} />
              <span className="font-orbitron text-xs text-purple-400 tracking-widest">FIRST PERSON EDITION</span>
              <div className="h-px flex-1 max-w-[80px]" style={{ background: "linear-gradient(90deg, #a855f7, transparent)" }} />
            </div>

            <p className="text-white/50 mb-6 font-bold text-sm tracking-widest uppercase">
              🕹 FPS · 🌍 4 Worlds · 👥 Multiplayer · 🎮 Mini-Games
            </p>

            <div className="grid grid-cols-3 gap-2 mb-6 w-full max-w-sm">
              {[
                { emoji: "🎮", label: "FIRST PERSON", sub: "Raycaster Engine" },
                { emoji: "👥", label: "MULTIPLAYER", sub: "Live Players" },
                { emoji: "🏆", label: "EARN COINS", sub: "Leaderboards" },
              ].map(f => (
                <div key={f.label} className="rounded-xl p-3 border text-center"
                  style={{ background: "rgba(168,85,247,0.05)", borderColor: "rgba(168,85,247,0.25)" }}>
                  <div className="text-2xl mb-1">{f.emoji}</div>
                  <div className="text-purple-300 text-[10px] font-black font-orbitron leading-tight">{f.label}</div>
                  <div className="text-white/30 text-[9px]">{f.sub}</div>
                </div>
              ))}
            </div>

            <motion.button whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(168,85,247,0.8)" }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setStep("choose")}
              className="btn-primary text-white text-xl font-black px-16 py-5 pulse-glow font-orbitron tracking-wider">
              <Zap className="inline w-6 h-6 mr-2" /> PLAY NOW!
            </motion.button>

            <div className="mt-3 font-orbitron text-xs text-white/20 tracking-widest animate-pulse">
              © BUGGAGOOGEE STUDIOS · ALL RIGHTS RESERVED
            </div>
          </motion.div>
        )}

        {/* CHOOSE CHARACTER */}
        {step === "choose" && (
          <motion.div key="choose" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}
            className="w-full max-w-2xl">
            <h2 className="font-orbitron font-black text-3xl text-white text-center mb-2">Choose Your Character</h2>
            <p className="text-white/50 text-center mb-6">Who do you want to be in Buggagoogee's world?</p>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
              {CHARACTERS.map(char => (
                <motion.button key={char.id} whileHover={{ scale: 1.04, y: -3 }} whileTap={{ scale: 0.96 }}
                  onClick={() => setSelectedChar(char)}
                  className={`glass-card rounded-2xl p-4 border-2 transition-all text-center ${selectedChar?.id === char.id ? '' : 'border-white/10'}`}
                  style={selectedChar?.id === char.id ? {
                    borderColor: char.color,
                    boxShadow: `0 0 20px ${char.color}50`,
                  } : {}}>
                  <div className="text-5xl mb-2">{char.emoji}</div>
                  <div className="font-black text-white">{char.name}</div>
                  <div className="text-xs font-semibold mt-1" style={{ color: char.color }}>{char.description}</div>
                </motion.button>
              ))}
            </div>

            <AnimatePresence>
              {selectedChar && (
                <motion.button initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                  onClick={() => setStep("username")}
                  className="w-full py-4 rounded-2xl font-black text-xl text-white"
                  style={{ background: `linear-gradient(135deg, ${selectedChar.color}, ${selectedChar.color}99)` }}>
                  Play as {selectedChar.name} {selectedChar.emoji} →
                </motion.button>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* SET USERNAME */}
        {step === "username" && (
          <motion.div key="username" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}
            className="w-full max-w-md">
            <div className="text-center mb-6">
              <div className="text-7xl mb-3">{selectedChar?.emoji}</div>
              <h2 className="font-orbitron font-black text-3xl text-white mb-1">What's Your Name?</h2>
              <p className="text-white/50">This is how other players will see you!</p>
            </div>

            <div className="glass-card rounded-2xl p-6 border border-white/10 mb-4">
              <label className="text-white/60 text-sm font-bold uppercase tracking-wider block mb-2">Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value.slice(0, 16))}
                onKeyDown={e => e.key === "Enter" && handleStart()}
                placeholder="Enter your username..."
                maxLength={16}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white font-bold text-lg placeholder-white/30 outline-none focus:border-purple-400 transition-colors"
              />
              <div className="text-white/30 text-xs mt-1 text-right">{username.length}/16</div>
              {error && <p className="text-red-400 text-sm font-bold mt-2">{error}</p>}
            </div>

            <div className="glass-card rounded-2xl p-3 border border-white/10 mb-6 flex items-center gap-3">
              <Users className="w-5 h-5 text-cyan-400" />
              <p className="text-white/60 text-sm">Your progress saves automatically! Come back anytime with the same username + character.</p>
            </div>

            <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
              onClick={() => {
                if (!username.trim() || username.trim().length < 2) { setError("Username must be at least 2 characters!"); return; }
                setError("");
                setCustomization({ color: selectedChar?.color || "#a855f7", outfit: "default", outfitEmoji: null });
                setStep("customize");
              }}
              className="w-full py-5 rounded-2xl font-black text-xl text-white transition-all"
              style={{ background: `linear-gradient(135deg, ${selectedChar?.color}, ${selectedChar?.color}99)` }}>
              Next: Customize →
            </motion.button>

            <button onClick={() => setStep("choose")} className="w-full mt-3 py-3 text-white/40 font-semibold hover:text-white/70 transition-colors">
              ← Back
            </button>
          </motion.div>
        )}
        {/* CUSTOMIZE */}
        {step === "customize" && (
          <CharacterCustomize
            character={selectedChar}
            initialColor={customization.color}
            onConfirm={(c) => { setCustomization(c); handleStart(); }}
            onBack={() => setStep("username")}
          />
        )}

      </AnimatePresence>
    </div>
  );
}