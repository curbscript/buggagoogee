import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const ROXY_MESSAGES = {
  idle: ["Woof! Let's go! 🐾", "I believe in you! 💪", "You've got this! ⭐", "Adventure awaits! 🌟"],
  correct: ["AMAZING! 🎉", "YES YES YES! 🏆", "You're a GENIUS! 🧠", "Tail wagging intensifies! 🐕"],
  wrong: ["Aww, try again! 🐾", "We'll get it! 💪", "Almost! Keep going! ✨", "Roxy believes in you! 🐕"],
  hint: ["Hmm... think about it! 🤔", "I know this one! 🐾", "You can do it! ⭐", "Focus! 🎯"],
  levelup: ["LEVEL UP!! 🎊", "We're unstoppable! 🚀", "WOOF WOOF WOOF! 🐕", "Party time! 🎉"],
};

export default function RoxyCompanion({ outfit = "default", mood = "idle", onRoxyClick, tricks = [] }) {
  const [showBubble, setShowBubble] = useState(true);
  const [message, setMessage] = useState(ROXY_MESSAGES.idle[0]);

  const outfitEmojis = {
    default: "🐕",
    astronaut: "🐕‍🦺",
    explorer: "🦮",
    wizard: "🐩",
    cyber: "🤖",
  };

  const handleClick = () => {
    const msgs = ROXY_MESSAGES[mood] || ROXY_MESSAGES.idle;
    const newMsg = msgs[Math.floor(Math.random() * msgs.length)];
    setMessage(newMsg);
    setShowBubble(true);
    if (onRoxyClick) onRoxyClick();
  };

  return (
    <div className="flex flex-col items-center select-none">
      <AnimatePresence>
        {showBubble && (
          <motion.div
            initial={{ opacity: 0, y: 5, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 5, scale: 0.9 }}
            className="mb-2 max-w-[140px] text-center"
          >
            <div className="glass-card rounded-2xl px-3 py-2 border border-purple-400/30 relative">
              <p className="text-xs font-bold text-purple-200">{message}</p>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3 h-3 glass-card border-l border-b border-purple-400/30 rotate-45" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={handleClick}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="roxy-bounce cursor-pointer"
      >
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl"
            style={{
              background: 'rgba(168,85,247,0.2)',
              border: '2px solid rgba(168,85,247,0.4)',
              boxShadow: '0 0 15px rgba(168,85,247,0.3)',
            }}
          >
            {outfitEmojis[outfit] || "🐕"}
          </div>
          {tricks.length > 0 && (
            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center text-xs font-black text-yellow-900">
              {tricks.length}
            </div>
          )}
        </div>
        <p className="text-xs text-purple-300/70 mt-1 font-bold">Roxy</p>
      </motion.button>
    </div>
  );
}